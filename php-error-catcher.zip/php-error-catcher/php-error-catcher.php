<?php
/**
 * Plugin Name: PHP Error Catcher & Diagnoser
 * Description: A powerful tool that catches, stores, and diagnoses all PHP errors, exceptions, and fatal shutdowns.
 * Version: 1.0.0
 * Author: Omotayo Sonde
 * Author URI: https://my-portfolio-xs.vercel.app/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PHP_Error_Catcher {

	private static $instance = null;
	private $table_name;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		global $wpdb;
		$this->table_name = $wpdb->prefix . 'php_error_logs';

		// Register hooks
		register_activation_hook( __FILE__, [ $this, 'activate' ] );
		
		// Initialize error handling as early as possible
		$this->init_handlers();

		// Admin interface
		if ( is_admin() ) {
			add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
			add_action( 'wp_ajax_diagnose_with_xon_ai', [ $this, 'ajax_diagnose_with_xon_ai' ] );
		}
	}

	public function ajax_diagnose_with_xon_ai() {
		check_ajax_referer( 'xon_ai_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$log_id = intval( $_POST['log_id'] );
		global $wpdb;
		$log = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $this->table_name WHERE id = %d", $log_id ) );

		if ( ! $log ) {
			wp_send_json_error( 'Log entry not found.' );
		}

		$unique_key = get_option( 'xon_ai_unique_key' );
		if ( ! $unique_key ) {
			wp_send_json_error( 'Xon AI Unique Key not set. Please update settings.' );
		}

		$prompt = "Diagnose this PHP error and provide suggestions to fix it:\n\n" .
				  "Type: " . $log->type . "\n" .
				  "Message: " . $log->message . "\n" .
				  "File: " . $log->file . "\n" .
				  "Line: " . $log->line . "\n" .
				  "Stack Trace: " . $log->stack_trace;

		$response = wp_remote_post( 'https://xon-ai-zeta.vercel.app/api/platform', [
			'headers' => [
				'Content-Type' => 'application/json',
			],
			'body'    => wp_json_encode( [
				'prompt'     => $prompt,
				'unique_key' => $unique_key,
			] ),
			'timeout' => 30,
		] );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( 'API request failed: ' . $response->get_error_message() );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['error'] ) ) {
			wp_send_json_error( 'Xon AI Error: ' . ( is_array( $data['error'] ) ? ( $data['error']['message'] ?? 'Unknown Error' ) : $data['error'] ) );
		}

		$diagnosis = '';
		if ( isset( $data['choices'][0]['message']['content'] ) ) {
			$diagnosis = $data['choices'][0]['message']['content'];
		} elseif ( isset( $data['response'] ) ) {
			$diagnosis = $data['response'];
		} else {
			wp_send_json_error( 'Unexpected response format from AI.' );
		}

		// Strip <think>...</think> tags if they exist for a cleaner display
		$diagnosis = preg_replace( '/<think>.*?<\/think>\s*/is', '', $diagnosis );

		wp_send_json_success( trim( $diagnosis ) );
	}

	public function activate() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $this->table_name (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			type varchar(50) NOT NULL,
			message text NOT NULL,
			file varchar(255) NOT NULL,
			line int(11) NOT NULL,
			stack_trace longtext,
			context longtext,
			url varchar(255),
			user_id bigint(20),
			created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
			PRIMARY KEY  (id)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
	}

	private function init_handlers() {
		set_error_handler( [ $this, 'handle_error' ] );
		set_exception_handler( [ $this, 'handle_exception' ] );
		register_shutdown_function( [ $this, 'handle_shutdown' ] );
	}

	public function handle_error( $errno, $errstr, $errfile, $errline ) {
		// Ignore suppressed errors (with @)
		if ( ! ( error_reporting() & $errno ) ) {
			return false;
		}

		$this->log_error( 'Error', $errstr, $errfile, $errline, debug_backtrace() );
		return false; // Let PHP continue its default handling
	}

	public function handle_exception( $exception ) {
		$this->log_error( 
			get_class( $exception ), 
			$exception->getMessage(), 
			$exception->getFile(), 
			$exception->getLine(), 
			$exception->getTrace() 
		);
	}

	public function handle_shutdown() {
		$error = error_get_last();
		if ( $error && in_array( $error['type'], [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR ] ) ) {
			$this->log_error( 'Fatal Error', $error['message'], $error['file'], $error['line'] );
		}
	}

	private function log_error( $type, $message, $file, $line, $trace = null ) {
		global $wpdb;

		// Avoid infinite loops if log_error itself fails
		static $is_logging = false;
		if ( $is_logging ) return;
		$is_logging = true;

		$context = [
			'GET' => $_GET,
			'POST' => $_POST,
			'SERVER' => [
				'HTTP_USER_AGENT' => $_SERVER['HTTP_USER_AGENT'] ?? '',
				'REMOTE_ADDR' => $_SERVER['REMOTE_ADDR'] ?? '',
				'REQUEST_METHOD' => $_SERVER['REQUEST_METHOD'] ?? '',
			]
		];

		$url = ( is_ssl() ? 'https://' : 'http://' ) . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '' );
		$user_id = get_current_user_id();

		$wpdb->insert(
			$this->table_name,
			[
				'type'        => $type,
				'message'     => $message,
				'file'        => $file,
				'line'        => $line,
				'stack_trace' => $trace ? wp_json_encode( $trace ) : null,
				'context'     => wp_json_encode( $context ),
				'url'         => $url,
				'user_id'     => $user_id,
				'created_at'  => current_time( 'mysql' )
			]
		);

		$is_logging = false;
	}

	public function add_admin_menu() {
		add_menu_page(
			'PHP Errors',
			'PHP Errors',
			'manage_options',
			'php-error-logs',
			[ $this, 'render_admin_page' ],
			'dashicons-warning'
		);
	}

	public function render_admin_page() {
		global $wpdb;
		
		?>
		<style>
			.xon-ai-shimmer {
				background: #f6f7f8;
				background-image: linear-gradient(to right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%);
				background-repeat: no-repeat;
				background-size: 800px 104px; 
				display: inline-block;
				position: relative; 
				animation-duration: 1s;
				animation-fill-mode: forwards; 
				animation-iteration-count: infinite;
				animation-name: shimmer;
				animation-timing-function: linear;
			}
			@keyframes shimmer {
				0% { background-position: -468px 0; }
				100% { background-position: 468px 0; }
			}
			.xon-ai-loading-placeholder {
				padding: 15px;
				border: 1px solid #ddd;
				background: #fff;
				margin-top: 10px;
			}
			.shimmer-line {
				height: 12px;
				margin-bottom: 10px;
				width: 100%;
				border-radius: 4px;
			}
			.shimmer-line.short { width: 60%; }
			.shimmer-line.medium { width: 85%; }
		</style>
		<?php

		if ( isset( $_POST['xon_ai_settings'] ) ) {
			check_admin_referer( 'xon_ai_settings_save' );
			update_option( 'xon_ai_unique_key', sanitize_text_field( $_POST['xon_ai_unique_key'] ) );
			echo '<div class="updated"><p>Settings saved.</p></div>';
		}

		if ( isset( $_GET['action'] ) && 'delete' === $_GET['action'] && isset( $_GET['id'] ) ) {
			check_admin_referer( 'delete_error_log' );
			$wpdb->delete( $this->table_name, [ 'id' => intval( $_GET['id'] ) ] );
			echo '<div class="updated"><p>Log deleted.</p></div>';
		}

		if ( isset( $_GET['action'] ) && 'clear' === $_GET['action'] ) {
			check_admin_referer( 'clear_error_logs' );
			$wpdb->query( "TRUNCATE TABLE $this->table_name" );
			echo '<div class="updated"><p>All logs cleared.</p></div>';
		}

		if ( isset( $_GET['action'] ) && 'test_error' === $_GET['action'] ) {
			check_admin_referer( 'test_error' );
			trigger_error( "This is a test warning triggered by the user.", E_USER_WARNING );
			echo '<div class="updated"><p>Test warning triggered and logged below.</p></div>';
		}

		$logs = $wpdb->get_results( "SELECT * FROM $this->table_name ORDER BY created_at DESC LIMIT 100" );
		$xon_ai_key = get_option( 'xon_ai_unique_key', '' );

		?>
		<div class="wrap">
			<h1>PHP Error Logs</h1>
			
			<div class="card" style="max-width: 100%; margin-top: 20px;">
				<h2>Xon AI Settings</h2>
				<form method="post" action="">
					<?php wp_nonce_field( 'xon_ai_settings_save' ); ?>
					<table class="form-table">
						<tr>
							<th scope="row"><label for="xon_ai_unique_key">Unique Key</label></th>
							<td>
								<input name="xon_ai_unique_key" type="password" id="xon_ai_unique_key" value="<?php echo esc_attr( $xon_ai_key ); ?>" class="regular-text">
								<p class="description">Get your key from <a href="https://xon-ai-zeta.vercel.app/" target="_blank">xon-ai-zeta.vercel.app</a></p>
							</td>
						</tr>
					</table>
					<p class="submit">
						<input type="submit" name="xon_ai_settings" id="submit" class="button button-primary" value="Save Settings">
					</p>
				</form>
			</div>

			<p>
				<a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=php-error-logs&action=test_error' ), 'test_error' ); ?>" class="button button-primary">Trigger Test Error</a>
				<a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=php-error-logs&action=clear' ), 'clear_error_logs' ); ?>" class="button button-secondary" onclick="return confirm('Clear all logs?');">Clear All Logs</a>
			</p>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th width="150">Time</th>
						<th width="100">Type</th>
						<th>Message</th>
						<th>Location</th>
						<th width="100">Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php if ( $logs ) : ?>
						<?php foreach ( $logs as $log ) : ?>
							<tr>
								<td><?php echo esc_html( $log->created_at ); ?></td>
								<td><strong><?php echo esc_html( $log->type ); ?></strong></td>
								<td>
									<div style="word-break: break-all;">
										<?php echo esc_html( $log->message ); ?>
									</div>
									<div style="margin-top: 5px; font-size: 0.85em; color: #666;">
										URL: <a href="<?php echo esc_url( $log->url ); ?>" target="_blank"><?php echo esc_html( $log->url ); ?></a>
									</div>
								</td>
								<td>
									<code><?php echo esc_html( str_replace( ABSPATH, '', $log->file ) ); ?></code>:<?php echo intval( $log->line ); ?>
								</td>
								<td>
									<button class="button button-small view-details" data-id="<?php echo esc_attr( $log->id ); ?>">Details</button>
									<a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=php-error-logs&action=delete&id=' . $log->id ), 'delete_error_log' ); ?>" class="button button-small button-link-delete" onclick="return confirm('Delete this log?');">Delete</a>
								</td>
							</tr>
							<tr id="details-<?php echo esc_attr( $log->id ); ?>" style="display:none;">
								<td colspan="5" style="background: #f0f0f1; padding: 15px;">
									<div class="details-content">
										<h3>Stack Trace</h3>
										<pre style="background: #fff; padding: 10px; border: 1px solid #ccc; overflow: auto; max-height: 300px;"><?php 
											$trace = json_decode( $log->stack_trace, true );
											if ( is_array( $trace ) ) {
												foreach ( $trace as $i => $step ) {
													printf( "#%d %s:%d %s%s%s()\n", 
														$i, 
														esc_html( str_replace( ABSPATH, '', $step['file'] ?? 'unknown' ) ), 
														$step['line'] ?? 0,
														$step['class'] ?? '',
														$step['type'] ?? '',
														$step['function'] ?? ''
													);
												}
											} else {
												echo 'No stack trace available.';
											}
										?></pre>

										<h3>Context</h3>
										<pre style="background: #fff; padding: 10px; border: 1px solid #ccc; overflow: auto; max-height: 200px;"><?php 
											echo esc_html( print_r( json_decode( $log->context, true ), true ) ); 
										?></pre>

										<h3>Standard Diagnosis</h3>
										<div style="background: #e7f3ff; padding: 10px; border-left: 4px solid #2271b1;">
											<?php echo $this->diagnose_error( $log->type, $log->message ); ?>
										</div>

										<h3>Xon AI Diagnosis</h3>
										<div class="xon-ai-diagnosis-container" style="margin-top: 10px;">
											<button class="button xon-ai-diagnose" data-id="<?php echo esc_attr( $log->id ); ?>">Diagnose with Xon AI</button>
											<div class="xon-ai-loading" style="display:none; margin-top: 10px;">
												<div class="xon-ai-loading-placeholder">
													<div class="xon-ai-shimmer shimmer-line"></div>
													<div class="xon-ai-shimmer shimmer-line medium"></div>
													<div class="xon-ai-shimmer shimmer-line short"></div>
													<div style="font-size: 0.9em; color: #666; font-style: italic;">Xon AI is analyzing the error...</div>
												</div>
											</div>
											<div class="xon-ai-result" style="margin-top: 10px; background: #fdfdfd; padding: 15px; border: 1px solid #ddd; display: none;">
												<div class="xon-ai-content" style="white-space: pre-wrap;"></div>
											</div>
										</div>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php else : ?>
						<tr><td colspan="5">No errors logged yet.</td></tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<script>
			jQuery(document).ready(function($) {
				function typeWriter(text, $element, speed = 20) {
					$element.html('');
					var i = 0;
					function type() {
						if (i < text.length) {
							$element.append(text.charAt(i));
							i++;
							setTimeout(type, speed);
						}
					}
					type();
				}

				$('.view-details').on('click', function() {
					var id = $(this).data('id');
					$('#details-' + id).toggle();
				});

				$('.xon-ai-diagnose').on('click', function() {
					var $btn = $(this);
					var id = $btn.data('id');
					var $container = $btn.siblings('.xon-ai-result');
					var $loading = $btn.siblings('.xon-ai-loading');
					var $content = $container.find('.xon-ai-content');

					$btn.prop('disabled', true);
					$container.hide();
					$loading.show();
					$content.html('');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'diagnose_with_xon_ai',
							log_id: id,
							nonce: '<?php echo wp_create_nonce( "xon_ai_nonce" ); ?>'
						},
						success: function(response) {
							$loading.hide();
							$container.show();
							if (response.success) {
								typeWriter(response.data, $content);
							} else {
								$content.html('<span style="color:red;">Error: ' + response.data + '</span>');
							}
							$btn.prop('disabled', false);
						},
						error: function() {
							$loading.hide();
							$container.show();
							$content.html('<span style="color:red;">Failed to connect to server.</span>');
							$btn.prop('disabled', false);
						}
					});
				});
			});
		</script>
		<?php
	}

	private function diagnose_error( $type, $message ) {
		$diagnosis = "No specific diagnosis available.";

		if ( stripos( $message, 'Allowed memory size' ) !== false ) {
			$diagnosis = "<strong>Memory Limit Exceeded:</strong> Your site is trying to use more RAM than allowed. <br><strong>Suggestion:</strong> Increase the memory limit in wp-config.php: <code>define('WP_MEMORY_LIMIT', '256M');</code>";
		} elseif ( stripos( $message, 'maximum execution time' ) !== false ) {
			$diagnosis = "<strong>Execution Timeout:</strong> A script took too long to finish. <br><strong>Suggestion:</strong> Increase <code>max_execution_time</code> in php.ini or check for infinite loops in your code.";
		} elseif ( stripos( $message, 'undefined function' ) !== false ) {
			$diagnosis = "<strong>Call to Undefined Function:</strong> The code is trying to use a function that doesn't exist. <br><strong>Suggestion:</strong> This often happens when a plugin/theme is deactivated or a file is missing. Check if the required plugin is active.";
		} elseif ( stripos( $message, 'Call to a member function' ) !== false && stripos( $message, 'on null' ) !== false ) {
			$diagnosis = "<strong>Call on Null Object:</strong> You are trying to use a method on a variable that is currently <code>null</code>. <br><strong>Suggestion:</strong> Add a check before using the variable, e.g., <code>if ( $variable ) { $variable->method(); }</code>";
		} elseif ( $type === 'Parse Error' || stripos( $message, 'syntax error' ) !== false ) {
			$diagnosis = "<strong>Syntax Error:</strong> There is a typo in your code (missing semicolon, bracket, etc.). <br><strong>Suggestion:</strong> Check the file and line number mentioned above for typos.";
		}

		return $diagnosis;
	}
}

PHP_Error_Catcher::instance();
